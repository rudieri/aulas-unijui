/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.banda;

import com.bandacomponente.BandaComponente;
import com.bandacomponente.BandaComponenteBD;
import com.bandacomponente.BandaComponenteSC;
import com.componente.Componente;
import com.componente.ComponenteBD;
import com.componente.JComponentes;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author janiel
 */
public class JBanda extends javax.swing.JDialog {

    private Banda banda;
    private JComponentes jConsultaComponentes;

    /**
     * Creates new form JBanda
     *
     * @param parent
     * @param modal
     */
    public JBanda(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
    }

    private void init() {
        this.pack();
        initTabelaBandas();
        initTabelaComponentes();
        setModoInclusao();
        pack();
        repaint();
    }

    private void initTabelaBandas() {
        DefaultTableModel tm = new DefaultTableModel();
        tm.addColumn("Código");
        tm.addColumn("Nome");
        tm.addColumn("Gênero");
        tm.addColumn("Ano");
        tm.addColumn("Obj");

        jTable_Bandas.setModel(tm);
        jTable_Bandas.getColumnModel().getColumn(0).setPreferredWidth(20);
        jTable_Bandas.getColumnModel().getColumn(1).setPreferredWidth(400);
        jTable_Bandas.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTable_Bandas.getColumnModel().getColumn(3).setPreferredWidth(40);

        jTable_Bandas.getColumnModel().removeColumn(jTable_Bandas.getColumn("Obj"));

        jTable_Bandas.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent evt) {
                if (evt.getValueIsAdjusting() || jTable_Bandas.getSelectedRow() == -1) {
                    return;
                }
                setBanda();
                jTable_Bandas.clearSelection();
            }
        });
    }

    private void atualizarTabelaBandas() {
        DefaultTableModel tm = (DefaultTableModel) jTable_Bandas.getModel();
        BandaSC filtro = new BandaSC();
        try {
            ArrayList<Banda> listaBandas = BandaBD.listar(filtro);

            tm.setNumRows(0);
            for (Banda item : listaBandas) {
                Object[] row = new Object[tm.getColumnCount()];
                row[0] = item.getCodigo();
                row[1] = item.getNome();
                row[2] = item.getGenero();
                row[3] = item.getAno() == 0 ? "" : item.getAno();
                row[4] = item;

                tm.addRow(row);
            }

            atualizarTabelaComponentes();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Atualizar Tabela. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void setBanda() {
        if (jTable_Bandas.getSelectedRow() == -1) {
            return;
        }
        banda = (Banda) jTable_Bandas.getModel().getValueAt(jTable_Bandas.getSelectedRow(), jTable_Bandas.getModel().getColumnCount() - 1);

        carregarBanda(banda);
    }

    private void setModoInclusao() {
        jButton_InserirBanda.setVisible(true);
        jButton_AlterarBanda.setVisible(false);
        jButton_RemoverBanda.setVisible(false);
        jButton_ConsultarBanda.setVisible(true);
        jTextField_NomeBanda.requestFocus();
        atualizarTabelaBandas();
    }

    private void setModoAlteracao() {
        jButton_InserirBanda.setVisible(false);
        jButton_AlterarBanda.setVisible(true);
        jButton_RemoverBanda.setVisible(true);
        jButton_ConsultarBanda.setVisible(false);
        jTextField_NomeBanda.requestFocus();
        atualizarTabelaBandas();
    }

    private void inserirBanda() {
        try {

            setDadosBanda();

            if (BandaBD.existe(banda)) {
                JOptionPane.showMessageDialog(this, "Esta Banda já existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaBD.inserir(banda);

            limparBanda();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Incluir. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao incluir. " + ex);
        }
    }

    private void alterarBanda() {
        try {
            if (banda == null) {
                JOptionPane.showMessageDialog(this, "Banda não informada! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }

            this.banda = BandaBD.existeCarregar(this.banda);
            if (this.banda == null) {
                JOptionPane.showMessageDialog(this, "Esta Banda não existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            setDadosBanda();

            banda.setNome(jTextField_NomeBanda.getText());
            banda.setGenero(jTextField_Genero.getText());
            if (!jTextField_Ano.getText().trim().isEmpty()) {
                banda.setAno(Integer.parseInt(jTextField_Ano.getText()));
            }

            BandaBD.alterar(banda);

            limparBanda();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Alterar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao alterar. " + ex);
        }
    }

    private void removerBanda() {
        if (banda == null) {
            JOptionPane.showMessageDialog(this, "Banda não informada! ", "Aviso", JOptionPane.OK_OPTION);
            return;
        }

        if (JOptionPane.showConfirmDialog(this, "Deseja realmente remover Banda? ", "Confirme", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            if (!BandaBD.existe(banda)) {
                JOptionPane.showMessageDialog(this, "Esta Banda não existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            
            BandaComponenteSC filtro = new BandaComponenteSC();
            filtro.setBanda(banda);
            ArrayList<BandaComponente> listaBandaComponentes = BandaComponenteBD.listar(filtro);
            for (BandaComponente bandaComponente : listaBandaComponentes) {
                BandaComponenteBD.excluir(bandaComponente);
            }
            
            BandaBD.excluir(banda);

            limparBanda();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Excluir. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao excluir. " + ex);
        }
    }

    private void consultarBanda() {
        try {
            banda = new Banda();

            if (!jTextField_CodigoBanda.getText().trim().isEmpty()) {
                banda.setCodigo(Integer.parseInt(jTextField_CodigoBanda.getText()));
            }
            if (!jTextField_NomeBanda.getText().trim().isEmpty()) {
                banda.setNome(jTextField_NomeBanda.getText().trim());
            }

            banda = BandaBD.existeCarregar(banda);

            if (banda == null) {
                JOptionPane.showMessageDialog(this, "Banda não encontrada! ", "Aviso", JOptionPane.OK_OPTION);
            } else {
                carregarBanda(banda);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Consultar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void setDadosBanda() {
        if (this.banda == null) {
            banda = new Banda();
        }

        banda.setNome(jTextField_NomeBanda.getText().trim());
        banda.setGenero(jTextField_Genero.getText());
        if (jTextField_Ano.getText() != null && !jTextField_Ano.getText().trim().isEmpty() && jTextField_Ano.getText().trim().replaceAll("[0-9]", "").trim().isEmpty()) {
            banda.setAno(Integer.parseInt(jTextField_Ano.getText()));
        }
    }

    private void carregarBanda(Banda banda) {
        limparBanda();
        this.banda = banda;
        jTextField_CodigoBanda.setText(banda.getCodigo().toString());
        jTextField_NomeBanda.setText(banda.getNome().trim());
        jTextField_Genero.setText(banda.getGenero());
        jTextField_Ano.setText(banda.getAno() == 0 ? "" : String.valueOf(banda.getAno()));

        atualizarTabelaComponentes();

        setModoAlteracao();
    }

    private void limparBanda() {
        banda = null;
        jTextField_CodigoBanda.setText("");
        jTextField_NomeBanda.setText("");
        jTextField_Genero.setText("");
        jTextField_CodComponente.setText("");
        jTextField_NomeComponente.setText("");
        jTextField_Ano.setText("");
        atualizarTabelaComponentes();
        setModoInclusao();
    }

    private void initTabelaComponentes() {
        DefaultTableModel tm = new DefaultTableModel();
        tm.addColumn("Código");
        tm.addColumn("Nome");
        tm.addColumn("Obj");

        jTable_Componentes.setModel(tm);
        jTable_Componentes.getColumnModel().getColumn(0).setPreferredWidth(20);
        jTable_Componentes.getColumnModel().getColumn(1).setPreferredWidth(400);

        jTable_Componentes.getColumnModel().removeColumn(jTable_Componentes.getColumn("Obj"));

        jTable_Componentes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent evt) {
                if (evt.getValueIsAdjusting() || jTable_Componentes.getSelectedRow() == -1) {
                    return;
                }
                setComponente((Componente) jTable_Componentes.getModel().getValueAt(jTable_Componentes.getSelectedRow(), jTable_Componentes.getModel().getColumnCount() - 1));
                jTable_Componentes.clearSelection();
            }
        });
    }

    private void atualizarTabelaComponentes() {
        DefaultTableModel tm = (DefaultTableModel) jTable_Componentes.getModel();
        BandaComponenteSC filtro = new BandaComponenteSC();
        if (this.banda == null) {
            tm.setNumRows(0);
            return;
        }
        filtro.setBanda(this.banda);
        try {
            ArrayList<BandaComponente> listaBandaComponentes = BandaComponenteBD.listar(filtro);

            tm.setNumRows(0);
            for (BandaComponente item : listaBandaComponentes) {
                Object[] row = new Object[tm.getColumnCount()];
                row[0] = item.getComponente().getCodigo();
                row[1] = item.getComponente().getNome();
                row[2] = item.getComponente();

                tm.addRow(row);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Atualizar Tabela. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void adicionarComponente() {
        try {
            if (banda == null) {
                setDadosBanda();

                if (BandaBD.existe(banda)) {
                    JOptionPane.showMessageDialog(this, "Esta Banda já existe! ", "Aviso", JOptionPane.OK_OPTION);
                    return;
                }
                BandaBD.inserir(banda);

                banda = BandaBD.existeCarregar(banda);
                atualizarTabelaBandas();
            }
            if (banda == null || banda.getCodigo() == null) {
                JOptionPane.showMessageDialog(this, "Banda não informada! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            if (jTextField_CodComponente.getText() == null || jTextField_CodComponente.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Código não informado! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            Componente componente = new Componente();
            componente.setCodigo(Integer.parseInt(jTextField_CodComponente.getText()));

            componente = ComponenteBD.existeCarregar(componente);
            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Componente não encontrado! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaComponente bandaComponente = new BandaComponente();
            bandaComponente.setBanda(banda);
            bandaComponente.setComponente(componente);

            if (BandaComponenteBD.existe(bandaComponente)) {
                JOptionPane.showMessageDialog(this, "Banda já contém este componente! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaComponenteBD.inserir(bandaComponente);

            atualizarTabelaComponentes();
            jTextField_CodComponente.setText("");
            jTextField_NomeComponente.setText("");
            jTextField_NomeComponente.requestFocus();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Consultar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void removerComponente() {
        try {
            if (banda == null || banda.getCodigo() == null) {
                JOptionPane.showMessageDialog(this, "Banda não informada! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            if (jTextField_CodComponente.getText() == null || jTextField_CodComponente.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Código não informado! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            Componente componente = new Componente();
            componente.setCodigo(Integer.parseInt(jTextField_CodComponente.getText()));

            componente = ComponenteBD.existeCarregar(componente);
            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Componente não encontrado! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaComponente bandaComponente = new BandaComponente();
            bandaComponente.setBanda(banda);
            bandaComponente.setComponente(componente);
            bandaComponente = BandaComponenteBD.existeCarregar(bandaComponente);

            if (bandaComponente == null) {
                JOptionPane.showMessageDialog(this, "Banda não contém este componente! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaComponenteBD.excluir(bandaComponente);

            atualizarTabelaComponentes();
            jTextField_CodComponente.setText("");
            jTextField_NomeComponente.setText("");
            jTextField_NomeComponente.requestFocus();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Consultar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void buscarComponente() {
        if (jConsultaComponentes == null) {
            jConsultaComponentes = new JComponentes(this, true);
        }
        jConsultaComponentes.setVisible(true);

        if (jConsultaComponentes.getComponente() != null) {
            setComponente(jConsultaComponentes.getComponente());
        }
    }

    private void carregarComponente() {
        try {
            Componente componente = new Componente();

            if (!jTextField_CodComponente.getText().trim().isEmpty()) {
                componente.setCodigo(Integer.parseInt(jTextField_CodComponente.getText()));
            }

            componente = ComponenteBD.existeCarregar(componente);

            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Componente não encontrado! ", "Aviso", JOptionPane.OK_OPTION);
            } else {
                setComponente(componente);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Consultar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void setComponente(Componente componente) {
        if (componente != null) {
            jTextField_CodComponente.setText(componente.getCodigo().toString());
            jTextField_NomeComponente.setText(componente.getNome());
        } else {
            jTextField_CodComponente.setText("");
            jTextField_NomeComponente.setText("");
        }
    }

    public static void main(String[] args) {
        JBanda jBanda = new JBanda(null, true);
        jBanda.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel_Conteudo = new javax.swing.JPanel();
        jPanel_InserirBanda = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jTextField_CodigoBanda = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField_NomeBanda = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField_Genero = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField_Ano = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTextField_CodComponente = new javax.swing.JTextField();
        jTextField_NomeComponente = new javax.swing.JTextField();
        jButton_BuscarComponente = new javax.swing.JButton();
        jButton_AddComponente = new javax.swing.JButton();
        jButton_RemoveComponente = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable_Componentes = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Bandas = new javax.swing.JTable();
        jPanel41 = new javax.swing.JPanel();
        jButton_InserirBanda = new javax.swing.JButton();
        jButton_AlterarBanda = new javax.swing.JButton();
        jButton_RemoverBanda = new javax.swing.JButton();
        jButton_ConsultarBanda = new javax.swing.JButton();
        jButton_LimparBanda = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Bandas");

        jPanel_Conteudo.setPreferredSize(new java.awt.Dimension(800, 450));
        jPanel_Conteudo.setLayout(new javax.swing.BoxLayout(jPanel_Conteudo, javax.swing.BoxLayout.Y_AXIS));

        jPanel_InserirBanda.setPreferredSize(new java.awt.Dimension(800, 450));
        jPanel_InserirBanda.setLayout(new java.awt.BorderLayout());

        jPanel7.setPreferredSize(new java.awt.Dimension(800, 420));
        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.Y_AXIS));

        jPanel36.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));
        jPanel7.add(jPanel36);

        jPanel10.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel5.setText("Código:");
        jLabel5.setPreferredSize(new java.awt.Dimension(120, 17));
        jPanel10.add(jLabel5);

        jTextField_CodigoBanda.setEditable(false);
        jTextField_CodigoBanda.setPreferredSize(new java.awt.Dimension(100, 24));
        jPanel10.add(jTextField_CodigoBanda);

        jPanel7.add(jPanel10);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel1.setText("Nome:");
        jLabel1.setPreferredSize(new java.awt.Dimension(120, 17));
        jPanel1.add(jLabel1);

        jTextField_NomeBanda.setPreferredSize(new java.awt.Dimension(500, 24));
        jPanel1.add(jTextField_NomeBanda);

        jPanel7.add(jPanel1);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel2.setText("Gênero:");
        jLabel2.setPreferredSize(new java.awt.Dimension(120, 17));
        jPanel2.add(jLabel2);

        jTextField_Genero.setPreferredSize(new java.awt.Dimension(500, 24));
        jPanel2.add(jTextField_Genero);

        jPanel7.add(jPanel2);

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel4.setText("Ano:");
        jLabel4.setPreferredSize(new java.awt.Dimension(120, 17));
        jPanel4.add(jLabel4);

        jTextField_Ano.setPreferredSize(new java.awt.Dimension(100, 24));
        jPanel4.add(jTextField_Ano);

        jPanel7.add(jPanel4);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel3.setText("Componentes:");
        jLabel3.setPreferredSize(new java.awt.Dimension(120, 17));
        jPanel3.add(jLabel3);

        jTextField_CodComponente.setPreferredSize(new java.awt.Dimension(70, 24));
        jTextField_CodComponente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField_CodComponenteKeyPressed(evt);
            }
        });
        jPanel3.add(jTextField_CodComponente);

        jTextField_NomeComponente.setEditable(false);
        jTextField_NomeComponente.setPreferredSize(new java.awt.Dimension(340, 24));
        jPanel3.add(jTextField_NomeComponente);

        jButton_BuscarComponente.setFont(new java.awt.Font("Ubuntu", 1, 14)); // NOI18N
        jButton_BuscarComponente.setText("Buscar");
        jButton_BuscarComponente.setPreferredSize(new java.awt.Dimension(80, 24));
        jButton_BuscarComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BuscarComponenteActionPerformed(evt);
            }
        });
        jPanel3.add(jButton_BuscarComponente);

        jButton_AddComponente.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton_AddComponente.setText("+");
        jButton_AddComponente.setPreferredSize(new java.awt.Dimension(50, 24));
        jButton_AddComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddComponenteActionPerformed(evt);
            }
        });
        jPanel3.add(jButton_AddComponente);

        jButton_RemoveComponente.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton_RemoveComponente.setText("-");
        jButton_RemoveComponente.setPreferredSize(new java.awt.Dimension(50, 24));
        jButton_RemoveComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RemoveComponenteActionPerformed(evt);
            }
        });
        jPanel3.add(jButton_RemoveComponente);

        jPanel7.add(jPanel3);

        jPanel8.setBorder(null);
        jPanel8.setFont(new java.awt.Font("Ubuntu", 0, 15)); // NOI18N
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jPanel9.setPreferredSize(new java.awt.Dimension(120, 10));
        jPanel8.add(jPanel9);

        jScrollPane4.setPreferredSize(new java.awt.Dimension(500, 80));
        jScrollPane4.setRequestFocusEnabled(false);

        jTable_Componentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable_Componentes.setPreferredSize(new java.awt.Dimension(300, 65));
        jScrollPane4.setViewportView(jTable_Componentes);

        jPanel8.add(jScrollPane4);

        jPanel7.add(jPanel8);

        jPanel11.setLayout(new java.awt.BorderLayout());
        jPanel7.add(jPanel11);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Ubuntu", 0, 15)), "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Ubuntu", 0, 15), new java.awt.Color(57, 43, 43))); // NOI18N
        jPanel5.setFont(new java.awt.Font("Ubuntu", 0, 15)); // NOI18N
        jPanel5.setPreferredSize(new java.awt.Dimension(456, 210));
        jPanel5.setLayout(new java.awt.BorderLayout());

        jScrollPane2.setPreferredSize(new java.awt.Dimension(452, 200));

        jTable_Bandas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable_Bandas);

        jPanel5.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel7.add(jPanel5);

        jPanel_InserirBanda.add(jPanel7, java.awt.BorderLayout.PAGE_START);

        jPanel41.setPreferredSize(new java.awt.Dimension(800, 28));
        jPanel41.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 1));

        jButton_InserirBanda.setText("Inserir");
        jButton_InserirBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_InserirBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_InserirBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_InserirBanda);

        jButton_AlterarBanda.setText("Alterar");
        jButton_AlterarBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_AlterarBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AlterarBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_AlterarBanda);

        jButton_RemoverBanda.setText("Remover");
        jButton_RemoverBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_RemoverBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RemoverBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_RemoverBanda);

        jButton_ConsultarBanda.setText("Buscar");
        jButton_ConsultarBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_ConsultarBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ConsultarBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_ConsultarBanda);

        jButton_LimparBanda.setText("Limpar");
        jButton_LimparBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_LimparBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_LimparBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_LimparBanda);

        jPanel_InserirBanda.add(jPanel41, java.awt.BorderLayout.SOUTH);

        jPanel_Conteudo.add(jPanel_InserirBanda);

        getContentPane().add(jPanel_Conteudo, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_LimparBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_LimparBandaActionPerformed
        limparBanda();
    }//GEN-LAST:event_jButton_LimparBandaActionPerformed

    private void jButton_RemoverBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RemoverBandaActionPerformed
        removerBanda();
    }//GEN-LAST:event_jButton_RemoverBandaActionPerformed

    private void jButton_InserirBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_InserirBandaActionPerformed
        inserirBanda();
    }//GEN-LAST:event_jButton_InserirBandaActionPerformed

    private void jButton_AddComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddComponenteActionPerformed
        adicionarComponente();
    }//GEN-LAST:event_jButton_AddComponenteActionPerformed

    private void jButton_RemoveComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RemoveComponenteActionPerformed
        removerComponente();
    }//GEN-LAST:event_jButton_RemoveComponenteActionPerformed

    private void jButton_AlterarBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AlterarBandaActionPerformed
        alterarBanda();
    }//GEN-LAST:event_jButton_AlterarBandaActionPerformed

    private void jButton_ConsultarBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ConsultarBandaActionPerformed
        consultarBanda();
    }//GEN-LAST:event_jButton_ConsultarBandaActionPerformed

    private void jButton_BuscarComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BuscarComponenteActionPerformed
        buscarComponente();
    }//GEN-LAST:event_jButton_BuscarComponenteActionPerformed

    private void jTextField_CodComponenteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_CodComponenteKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (jTextField_CodComponente.getText().trim().isEmpty()) {
                buscarComponente();
            } else {
                carregarComponente();
            }
        }
    }//GEN-LAST:event_jTextField_CodComponenteKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_AddComponente;
    private javax.swing.JButton jButton_AlterarBanda;
    private javax.swing.JButton jButton_BuscarComponente;
    private javax.swing.JButton jButton_ConsultarBanda;
    private javax.swing.JButton jButton_InserirBanda;
    private javax.swing.JButton jButton_LimparBanda;
    private javax.swing.JButton jButton_RemoveComponente;
    private javax.swing.JButton jButton_RemoverBanda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel_Conteudo;
    private javax.swing.JPanel jPanel_InserirBanda;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable_Bandas;
    private javax.swing.JTable jTable_Componentes;
    private javax.swing.JTextField jTextField_Ano;
    private javax.swing.JTextField jTextField_CodComponente;
    private javax.swing.JTextField jTextField_CodigoBanda;
    private javax.swing.JTextField jTextField_Genero;
    private javax.swing.JTextField jTextField_NomeBanda;
    private javax.swing.JTextField jTextField_NomeComponente;
    // End of variables declaration//GEN-END:variables
}
