/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.banda;

import com.bdconexao.DBConexao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author janiel
 */
public class BandaBD {

    public static void inserir(Banda banda) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String nome = "\'" + banda.getNome() + "\'";
        String genero = "\'" + banda.getGenero() + "\'";
        String ano = "\'" + String.valueOf(banda.getAno() + "\'");

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO tabbanda  ");
            sql.append("(codigo, nome, genero, ano) values(");
            sql.append(" nextval ('tabbanda_seq'), ").append(nome).append(", ").append(genero).append(", ").append(ano).append(")");

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void alterar(Banda banda) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = String.valueOf(banda.getCodigo());
        String nome = "\'" + banda.getNome() + "\'";
        String genero = "\'" + banda.getGenero() + "\'";
        String ano = "\'" + String.valueOf(banda.getAno() + "\'");

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE tabbanda SET ");
            sql.append("nome = ").append(nome).append(", ");
            sql.append("genero = ").append(genero).append(", ");
            sql.append("ano = ").append(ano).append(" ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void excluir(Banda banda) throws SQLException {
        DBConexao db = new DBConexao();

        Statement stm = db.getConection();

        try {
            String codigo = String.valueOf(banda.getCodigo());

            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM tabbanda ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            stm.close();
            db.conexao.close();
        }
    }

    public static ArrayList<Banda> listar(BandaSC filtro) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = filtro.getCodigo() == null ? null : String.valueOf(filtro.getCodigo());
        String nome = filtro.getNome();
        String ano = filtro.getAno() == null ? null : String.valueOf(filtro.getAno());

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda ");
        sql.append("WHERE true ");
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo);
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome LIKE \'").append(nome).append("%\'");
        }
        if (ano != null && !ano.trim().isEmpty()) {
            sql.append(" AND ano = \'").append(ano).append("\'");
        }
        sql.append(" ORDER BY codigo ");
        ArrayList<Banda> listaBandas = new ArrayList();
        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();

            while (rs.next()) {
                listaBandas.add(carregar(rs));
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return listaBandas;

    }

    private static Banda carregar(ResultSet rs) throws SQLException {
        Banda banda = new Banda();
        banda.setCodigo(rs.getInt("codigo"));
        banda.setNome(rs.getString("nome"));
        banda.setGenero(rs.getString("genero"));
        banda.setAno(Integer.parseInt(rs.getString("ano")));

        return banda;
    }

    public static Banda existeCarregar(Banda banda) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = banda.getCodigo() == null ? null : String.valueOf(banda.getCodigo());
        String nome = banda.getNome();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda ");
        sql.append("WHERE true ");
        Banda retorno = null;
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome LIKE \'").append(nome).append("%\'");
        }

        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno;
    }

    public static Boolean existe(Banda banda) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = banda.getCodigo() == null ? null : String.valueOf(banda.getCodigo());
        String nome = banda.getNome();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda ");
        sql.append("WHERE true ");
        Banda retorno = null;
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome like \'").append(nome).append("\' ");
        }

        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno != null;
    }
}
