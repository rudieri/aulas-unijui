/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.componente;

import com.bandacomponente.BandaComponente;
import com.bandacomponente.BandaComponenteBD;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author janiel
 */
public class JComponente extends javax.swing.JDialog {

    private Componente componente;

    /**
     * Creates new form JComponente
     *
     * @param parent
     * @param modal
     */
    public JComponente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
    }

    private void init() {
        repaint();
        this.pack();
        initTabelaComponentes();
        setModoInclusao();
    }

    private void initTabelaComponentes() {
        DefaultTableModel tm = new DefaultTableModel();
        tm.addColumn("Código");
        tm.addColumn("Nome");
        tm.addColumn("Data Nasc");
        tm.addColumn("Obj");

        jTable_Componentes.setModel(tm);
        jTable_Componentes.getColumnModel().getColumn(0).setPreferredWidth(20);
        jTable_Componentes.getColumnModel().getColumn(1).setPreferredWidth(400);
        jTable_Componentes.getColumnModel().getColumn(2).setPreferredWidth(100);

        jTable_Componentes.getColumnModel().removeColumn(jTable_Componentes.getColumn("Obj"));

        jTable_Componentes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent evt) {
                if (evt.getValueIsAdjusting()) {
                    return;
                }
                setComponente();
            }
        });
    }

    private void atualizarTabelaComponentes() {
        DefaultTableModel tm = (DefaultTableModel) jTable_Componentes.getModel();
        ComponenteSC filtro = new ComponenteSC();
        try {
            ArrayList<Componente> listaComponentes = ComponenteBD.listar(filtro);

            tm.setNumRows(0);
            for (Componente item : listaComponentes) {
                Object[] row = new Object[tm.getColumnCount()];
                row[0] = item.getCodigo();
                row[1] = item.getNome();
                row[2] = item.getDataNascimento();
                row[3] = item;

                tm.addRow(row);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Atualizar Tabela. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void setComponente() {
        if (jTable_Componentes.getSelectedRow() == -1) {
            return;
        }
        componente = (Componente) jTable_Componentes.getModel().getValueAt(jTable_Componentes.getSelectedRow(), jTable_Componentes.getModel().getColumnCount() - 1);

        carregarComponente(componente);
    }

    private void setModoInclusao() {
        jButton_InserirComponente.setVisible(true);
        jButton_AlterarComponente.setVisible(false);
        jButton_RemoverComponente.setVisible(false);
        jButton_ConsultarComponente.setVisible(true);
        jTextField_NomeComponente.requestFocus();
        atualizarTabelaComponentes();
    }

    private void setModoAlteracao() {
        jButton_InserirComponente.setVisible(false);
        jButton_AlterarComponente.setVisible(true);
        jButton_RemoverComponente.setVisible(true);
        jButton_ConsultarComponente.setVisible(false);
        jTextField_NomeComponente.requestFocus();
        atualizarTabelaComponentes();
    }

    private void inserirComponente() {
        try {

            setDadosComponente();

            if (ComponenteBD.existe(componente)) {
                JOptionPane.showMessageDialog(this, "Este Componente já existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            ComponenteBD.inserir(componente);

            limparComponente();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Incluir. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao incluir. " + ex);
        }
    }

    private void alterarComponente() {
        try {
            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Componente não informado! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }

            this.componente = ComponenteBD.existeCarregar(componente);
            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Este Componente não existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            setDadosComponente();

            componente.setNome(jTextField_NomeComponente.getText());
            if (!jTextField_DataNasc.getText().trim().isEmpty()) {
                componente.setDataNascimento(jTextField_DataNasc.getText());
            }

            ComponenteBD.alterar(componente);

            limparComponente();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Alterar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao alterar. " + ex);
        }
    }

    private void removerComponente() {
        if (componente == null) {
            JOptionPane.showMessageDialog(this, "Componente não informado! ", "Aviso", JOptionPane.OK_OPTION);
            return;
        }

        if (JOptionPane.showConfirmDialog(this, "Deseja realmente remover Componente? ", "Confirme", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) {
            return;
        }
        try {
            if (!ComponenteBD.existe(componente)) {
                JOptionPane.showMessageDialog(this, "Este Componente não existe! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }
            BandaComponente bandaComponente = new BandaComponente();
            bandaComponente.setComponente(componente);
            if (BandaComponenteBD.existe(bandaComponente)) {
                JOptionPane.showMessageDialog(this, "Existe banda(s) utilizando este Componente! ", "Aviso", JOptionPane.OK_OPTION);
                return;
            }

            ComponenteBD.excluir(componente);

            limparComponente();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Excluir. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println("Erro ao excluir. " + ex);
        }
    }

    private void consultarComponente() {
        try {
            componente = new Componente();

            if (!jTextField_CodigoComponente.getText().trim().isEmpty()) {
                componente.setCodigo(Integer.parseInt(jTextField_CodigoComponente.getText()));
            }
            if (!jTextField_NomeComponente.getText().trim().isEmpty()) {
                componente.setNome(jTextField_NomeComponente.getText().trim());
            }

            componente = ComponenteBD.existeCarregar(componente);

            if (componente == null) {
                JOptionPane.showMessageDialog(this, "Componente não encontrado! ", "Aviso", JOptionPane.OK_OPTION);
            } else {
                carregarComponente(componente);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao Consultar. " + ex, "Aviso", JOptionPane.OK_OPTION);
            System.out.println(ex);
        }
    }

    private void setDadosComponente() {
        if (componente == null) {
            componente = new Componente();
        }

        componente.setNome(jTextField_NomeComponente.getText().trim());
        componente.setDataNascimento("");
        if (jTextField_DataNasc.getText().trim().replaceAll("[0-9]", "").trim().isEmpty()) {
            if (jTextField_DataNasc.getText() != null && !jTextField_DataNasc.getText().trim().isEmpty()) {
                componente.setDataNascimento(jTextField_DataNasc.getText());
            }
        }
    }

    private void carregarComponente(Componente componente) {
        limparComponente();
        this.componente = componente;
        jTextField_CodigoComponente.setText(componente.getCodigo().toString());
        jTextField_NomeComponente.setText(componente.getNome().trim());
        jTextField_DataNasc.setText(componente.getDataNascimento());

        setModoAlteracao();
    }

    private void limparComponente() {
        jTextField_CodigoComponente.setText("");
        jTextField_NomeComponente.setText("");
        jTextField_DataNasc.setText("");
        setModoInclusao();
    }

    public static void main(String[] args) {
        JComponente jComponente = new JComponente(null, true);
        jComponente.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel_Conteudo = new javax.swing.JPanel();
        jPanel_InserirBanda = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jTextField_CodigoComponente = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField_NomeComponente = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField_DataNasc = new javax.swing.JTextField();
        jPanel11 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Componentes = new javax.swing.JTable();
        jPanel41 = new javax.swing.JPanel();
        jButton_InserirComponente = new javax.swing.JButton();
        jButton_AlterarComponente = new javax.swing.JButton();
        jButton_RemoverComponente = new javax.swing.JButton();
        jButton_ConsultarComponente = new javax.swing.JButton();
        jButton_LimparBanda = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de Componentes");

        jPanel_Conteudo.setPreferredSize(new java.awt.Dimension(700, 380));
        jPanel_Conteudo.setLayout(new javax.swing.BoxLayout(jPanel_Conteudo, javax.swing.BoxLayout.Y_AXIS));

        jPanel_InserirBanda.setPreferredSize(new java.awt.Dimension(400, 300));
        jPanel_InserirBanda.setLayout(new java.awt.BorderLayout());

        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.Y_AXIS));

        jPanel36.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));
        jPanel7.add(jPanel36);

        jPanel10.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel5.setText("Código:");
        jLabel5.setPreferredSize(new java.awt.Dimension(140, 17));
        jPanel10.add(jLabel5);

        jTextField_CodigoComponente.setEditable(false);
        jTextField_CodigoComponente.setPreferredSize(new java.awt.Dimension(100, 24));
        jPanel10.add(jTextField_CodigoComponente);

        jPanel7.add(jPanel10);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel1.setText("Nome:");
        jLabel1.setPreferredSize(new java.awt.Dimension(140, 17));
        jPanel1.add(jLabel1);

        jTextField_NomeComponente.setPreferredSize(new java.awt.Dimension(500, 24));
        jPanel1.add(jTextField_NomeComponente);

        jPanel7.add(jPanel1);

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 1));

        jLabel4.setText("Data Nascimento:");
        jLabel4.setPreferredSize(new java.awt.Dimension(140, 17));
        jPanel4.add(jLabel4);

        jTextField_DataNasc.setPreferredSize(new java.awt.Dimension(100, 24));
        jPanel4.add(jTextField_DataNasc);

        jPanel7.add(jPanel4);

        jPanel11.setLayout(new java.awt.BorderLayout());
        jPanel7.add(jPanel11);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Ubuntu", 0, 15)), "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Ubuntu", 0, 15), new java.awt.Color(57, 43, 43))); // NOI18N
        jPanel5.setFont(new java.awt.Font("Ubuntu", 0, 15)); // NOI18N
        jPanel5.setLayout(new java.awt.BorderLayout());

        jScrollPane2.setPreferredSize(new java.awt.Dimension(452, 260));

        jTable_Componentes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable_Componentes);

        jPanel5.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel7.add(jPanel5);

        jPanel_InserirBanda.add(jPanel7, java.awt.BorderLayout.PAGE_START);

        jPanel41.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 5, 1));

        jButton_InserirComponente.setText("Inserir");
        jButton_InserirComponente.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_InserirComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_InserirComponenteActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_InserirComponente);

        jButton_AlterarComponente.setText("Alterar");
        jButton_AlterarComponente.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_AlterarComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AlterarComponenteActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_AlterarComponente);

        jButton_RemoverComponente.setText("Remover");
        jButton_RemoverComponente.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_RemoverComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RemoverComponenteActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_RemoverComponente);

        jButton_ConsultarComponente.setText("Buscar");
        jButton_ConsultarComponente.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_ConsultarComponente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ConsultarComponenteActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_ConsultarComponente);

        jButton_LimparBanda.setText("Limpar");
        jButton_LimparBanda.setPreferredSize(new java.awt.Dimension(120, 26));
        jButton_LimparBanda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_LimparBandaActionPerformed(evt);
            }
        });
        jPanel41.add(jButton_LimparBanda);

        jPanel_InserirBanda.add(jPanel41, java.awt.BorderLayout.SOUTH);

        jPanel_Conteudo.add(jPanel_InserirBanda);

        getContentPane().add(jPanel_Conteudo, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_LimparBandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_LimparBandaActionPerformed
        limparComponente();
    }//GEN-LAST:event_jButton_LimparBandaActionPerformed

    private void jButton_RemoverComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RemoverComponenteActionPerformed
        removerComponente();
    }//GEN-LAST:event_jButton_RemoverComponenteActionPerformed

    private void jButton_InserirComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_InserirComponenteActionPerformed
        inserirComponente();
    }//GEN-LAST:event_jButton_InserirComponenteActionPerformed

    private void jButton_AlterarComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AlterarComponenteActionPerformed
        alterarComponente();
    }//GEN-LAST:event_jButton_AlterarComponenteActionPerformed

    private void jButton_ConsultarComponenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ConsultarComponenteActionPerformed
        consultarComponente();
    }//GEN-LAST:event_jButton_ConsultarComponenteActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_AlterarComponente;
    private javax.swing.JButton jButton_ConsultarComponente;
    private javax.swing.JButton jButton_InserirComponente;
    private javax.swing.JButton jButton_LimparBanda;
    private javax.swing.JButton jButton_RemoverComponente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel_Conteudo;
    private javax.swing.JPanel jPanel_InserirBanda;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable_Componentes;
    private javax.swing.JTextField jTextField_CodigoComponente;
    private javax.swing.JTextField jTextField_DataNasc;
    private javax.swing.JTextField jTextField_NomeComponente;
    // End of variables declaration//GEN-END:variables
}
