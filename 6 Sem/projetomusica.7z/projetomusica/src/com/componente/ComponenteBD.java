/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.componente;

import com.bdconexao.DBConexao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author janiel
 */
public class ComponenteBD {

    public static void inserir(Componente componente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String nome = "\'" + componente.getNome() + "\'";
        String dataNasc = componente.getDataNascimento() == null ? null : "\'" + String.valueOf(componente.getDataNascimento() + "\'");

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO tabcomponente  ");
            sql.append("(codigo, nome, dt_nasc) values(");
            sql.append(" nextval ('tabcomponente_seq'), ").append(nome).append(", ").append(dataNasc).append(")");

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void alterar(Componente componente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = String.valueOf(componente.getCodigo());
        String nome = "\'" + componente.getNome() + "\'";
        String dataNasc = componente.getDataNascimento() == null ? null : "\'" + String.valueOf(componente.getDataNascimento() + "\'");

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE tabcomponente SET ");
            sql.append("nome = ").append(nome).append(", ");
            sql.append("dt_nasc = ").append(dataNasc).append(" ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void excluir(Componente componente) throws SQLException {
        DBConexao db = new DBConexao();

        Statement stm = db.getConection();

        try {
            String codigo = String.valueOf(componente.getCodigo());

            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM tabcomponente ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            stm.close();
            db.conexao.close();
        }
    }

    public static ArrayList<Componente> listar(ComponenteSC filtro) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = filtro.getCodigo() == null ? null : String.valueOf(filtro.getCodigo());
        String nome = filtro.getNome();
        String dataNasc = filtro.getDataNascimento() == null ? null : String.valueOf(filtro.getDataNascimento());

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabcomponente ");
        sql.append("WHERE true ");
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo);
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome LIKE \'").append(nome).append("%\'");
        }
        if (dataNasc != null && !dataNasc.trim().isEmpty()) {
            sql.append(" AND dataNasc = \'").append(dataNasc).append("\'");
        }
        sql.append(" ORDER BY codigo ");
        ArrayList<Componente> listaComponentes = new ArrayList();
        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();

            while (rs.next()) {
                listaComponentes.add(carregar(rs));
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return listaComponentes;

    }

    private static Componente carregar(ResultSet rs) throws SQLException {
        Componente componente = new Componente();
        componente.setCodigo(rs.getInt("codigo"));
        componente.setNome(rs.getString("nome"));
        componente.setDataNascimento(rs.getString("dt_nasc") == null ? "" : rs.getString("dt_nasc"));

        return componente;
    }

    public static Componente existeCarregar(Componente componente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = componente.getCodigo() == null ? null : String.valueOf(componente.getCodigo());
        String nome = componente.getNome();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabcomponente ");
        sql.append("WHERE true ");
        Componente retorno = null;
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome LIKE \'").append(nome).append("%\'");
        }

        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno;
    }

    public static Boolean existe(Componente componente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String nome = componente.getNome();
        String codigo = componente.getCodigo() == null ? null : String.valueOf(componente.getCodigo());

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabcomponente ");
        sql.append("WHERE true ");
        Componente retorno = null;
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (nome != null && !nome.trim().isEmpty()) {
            sql.append(" AND nome like \'").append(nome).append("\' ");
        }

        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno != null;
    }
}
