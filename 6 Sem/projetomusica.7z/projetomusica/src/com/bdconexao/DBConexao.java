/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bdconexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author janiel
 */
public class DBConexao {
    private static final String CAMPO_URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String CAMPO_USUARIO = "postgres";
    private static final String CAMPO_SENHA = "administrador";
    public Connection conexao;
    
    public Statement getConection() {
        try {
            Class.forName("org.postgresql.Driver");  
            conexao = DriverManager.getConnection(CAMPO_URL, CAMPO_USUARIO, CAMPO_SENHA);  
            
            return conexao.createStatement();

        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro Ao Estabelecer Conexão. " + ex);
        }
        return null;
    }
    
}
