/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bandacomponente;

import com.componente.*;
import com.bdconexao.DBConexao;
import com.banda.Banda;
import com.banda.BandaBD;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author janiel
 */
public class BandaComponenteBD {

    public static void inserir(BandaComponente bandaComponente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigoBanda = "\'" + String.valueOf(bandaComponente.getBanda().getCodigo() + "\'");
        String codigoComp = "\'" + bandaComponente.getComponente().getCodigo() + "\'";

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("INSERT INTO tabbanda_componente ");
            sql.append("(codigo, codigo_banda, codigo_componente) values(");
            sql.append(" nextval ('tabbanda_componente_seq'), ").append(codigoBanda).append(", ").append(codigoComp).append(")");

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void alterar(BandaComponente bandaComponente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = String.valueOf(bandaComponente.getCodigo());
        String codigoBanda = "\'" + String.valueOf(bandaComponente.getBanda().getCodigo() + "\'");
        String codigoComp = "\'" + bandaComponente.getComponente().getCodigo() + "\'";

        try {
            StringBuilder sql = new StringBuilder();
            sql.append("UPDATE tabbanda_componente SET ");
            sql.append("codigo_banda = ").append(codigoBanda).append(", ");
            sql.append("codigo_componente = ").append(codigoComp).append(" ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            db.conexao.close();
            stm.close();
        }
    }

    public static void excluir(BandaComponente bandaComponente) throws SQLException {
        DBConexao db = new DBConexao();

        Statement stm = db.getConection();

        try {
            String codigo = String.valueOf(bandaComponente.getCodigo());

            StringBuilder sql = new StringBuilder();
            sql.append("DELETE FROM tabbanda_componente ");
            sql.append("WHERE codigo = ").append(codigo);

            System.out.println(sql.toString());
            stm.executeUpdate(sql.toString());

        } finally {
            stm.close();
            db.conexao.close();
        }
    }

    public static ArrayList<BandaComponente> listar(BandaComponenteSC filtro) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigoBanda = filtro.getBanda().getCodigo().toString();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda_componente bc ");
        sql.append("WHERE true ");
        if (codigoBanda != null && !codigoBanda.trim().isEmpty()) {
            sql.append(" AND bc.codigo_banda = ").append(codigoBanda);
        }
        sql.append(" ORDER BY codigo ");
        ArrayList<BandaComponente> listaComponentes = new ArrayList();
        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();

            while (rs.next()) {
                listaComponentes.add(carregar(rs));
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return listaComponentes;

    }

    private static BandaComponente carregar(ResultSet rs) throws SQLException {
        BandaComponente bandaComponente = new BandaComponente();
        bandaComponente.setCodigo(rs.getInt("codigo"));
        Banda banda = new Banda();
        banda.setCodigo(rs.getInt("codigo_banda"));
        bandaComponente.setBanda(BandaBD.existeCarregar(banda));
        Componente componente = new Componente();
        componente.setCodigo(rs.getInt("codigo_componente"));
        bandaComponente.setComponente(ComponenteBD.existeCarregar(componente));

        return bandaComponente;
    }

    public static BandaComponente existeCarregar(BandaComponente bandaComponente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = bandaComponente.getCodigo() == null ? null : String.valueOf(bandaComponente.getCodigo());
        String codBanda = bandaComponente.getBanda() == null || bandaComponente.getBanda().getCodigo() == null ? null : bandaComponente.getBanda().getCodigo().toString();
        String codComponente = bandaComponente.getComponente() == null || bandaComponente.getComponente().getCodigo() == null ? null : bandaComponente.getComponente().getCodigo().toString();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda_componente ");
        sql.append("WHERE true ");
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (codBanda != null && !codBanda.trim().isEmpty()) {
            sql.append(" AND codigo_banda = ").append(codBanda).append(" ");
        }
        if (codComponente != null && !codComponente.trim().isEmpty()) {
            sql.append(" AND codigo_componente = ").append(codComponente).append(" ");
        }
        BandaComponente retorno = null;

        ResultSet rs = null;

        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno;
    }

    public static Boolean existe(BandaComponente bandaComponente) throws SQLException {
        DBConexao db = new DBConexao();
        Statement stm = db.getConection();

        String codigo = bandaComponente.getCodigo() == null ? null : String.valueOf(bandaComponente.getCodigo());
        String codBanda = bandaComponente.getBanda() == null || bandaComponente.getBanda().getCodigo() == null ? null : bandaComponente.getBanda().getCodigo().toString();
        String codComponente = bandaComponente.getComponente() == null && bandaComponente.getComponente().getCodigo() == null ? null : bandaComponente.getComponente().getCodigo().toString();

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * From tabbanda_componente ");
        sql.append("WHERE true ");
        if (codigo != null && !codigo.trim().isEmpty()) {
            sql.append(" AND codigo = ").append(codigo).append(" ");
        }
        if (codBanda != null && !codBanda.trim().isEmpty()) {
            sql.append(" AND codigo_banda = ").append(codBanda).append(" ");
        }
        if (codComponente != null && !codComponente.trim().isEmpty()) {
            sql.append(" AND codigo_componente = ").append(codComponente).append(" ");
        }
        BandaComponente retorno = null;

        ResultSet rs = null;
        try {
            System.out.println(sql.toString());
            stm.executeQuery(sql.toString());
            rs = stm.getResultSet();
            if (rs.next()) {
                retorno = carregar(rs);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            stm.close();
            db.conexao.close();
        }
        return retorno != null;
    }
}
